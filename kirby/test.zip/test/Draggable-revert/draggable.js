$( function() {
    $( "#draggable" ).draggable({ revert: true });
  } );